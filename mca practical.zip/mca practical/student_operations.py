from student_module import Student

class StudentOperations:
    def add_student_details(self, student):
        with open("StuData.txt", "a") as file:
            file.write(f"{student.roll_number}, {student.name}, {student.dob_day}/{student.dob_month}/{student.dob_year}, {student.gender}, {student.email}\n")
        print(f"Student {student.name} added.")

    def replace_name(self, old_name, new_name):
        with open("StuData.txt", "r") as file:
            lines = file.readlines()

        with open("StuData.txt", "w") as file:
            for line in lines:
                file.write(line.replace(old_name, new_name))
        print(f"Name {old_name} replaced with {new_name}.")

# Using the classes
student = Student(1, "John Doe", 15, 8, 2000, "M", "john@example.com")
ops = StudentOperations()
ops.add_student_details(student)
ops.replace_name("John Doe", "John Smith")
