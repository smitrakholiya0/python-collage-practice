# import pickle
# games = [["Basket Ball", 102],
#     ["Football", 22],
#     ["Basket Ball", 42],
#     ["Tennis", 8]] 

# with open("gameD.dat","ab") as add:
#     for game in games:
#         pickle.dump(game, add)

# with open("gameD.dat","rb") as rid:
#     while True: 
#         try:
#             loaded= pickle.load(rid)
#             for item in loaded:
#                 if item == "Basket Ball":
#                     print(loaded)
#         except Exception as e:
#             break



# str1 = "smit is good boy"
# ln = 0
# store = ""
# for i in str1:
#     ln+=1
#     store=i+store
#     print(i)

# print(ln)
# print(store)


















import pickle
def writefunc(l1):
    with open("game1.dat","ab") as ad:
         pickle.dump(l1,ad)
def readfunc():
    with open("game1.dat","rb") as rb:
        while True:
            try:
                loded= pickle.load(rb)
                for item in loded:
                    if item[0]=="B":
                        print(loded)
            except:
                break


while True:
    val = int(input("enetr 1 for add deatils 2 for show details 3 for exit"))
    if(val==1):
            gname= input("enter name")
            participtnt= input("enter participtnt")
            l1=[gname, participtnt]
            writefunc(l1)

    elif(val==2):
        readfunc()
    elif(val==3):
        break
    else:
        print("enter valid input")


st1 = "hello smit"
count =0
rev=""

for i in st1:
    count+=1
    rev = i+rev

print(count)
print(rev)