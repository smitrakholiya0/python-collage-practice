class Student:
    def __init__(self, roll_number, name, dob_day, dob_month, dob_year, gender, email):
        self.roll_number = roll_number
        self.name = name
        self.dob_day = dob_day
        self.dob_month = dob_month
        self.dob_year = dob_year
        self.gender = gender
        self.email = email

    # Getter and Setter methods
    def get_name(self):
        return self.name

    def set_name(self, name):
        self.name = name
