# from datetime import datetime

# class Person:
#     def __init__(self):
#         self.name = None
#         self.country = None
#         self.dob = None  # Date of birth in DD-MM-YYYY format

#     def get_details(self):
#         """Get values of attributes from the user."""
#         self.name = input("Enter name: ")
#         self.country = input("Enter country: ")
#         dob_input = input("Enter date of birth (DD-MM-YYYY): ")
#         self.dob = datetime.strptime(dob_input, "%d-%m-%Y")

#     def calculate_age(self):
#         """Determine the person's age."""
#         today = datetime.now()
#         age = today.year - self.dob.year
#         # Adjust for a birthday that hasn't occurred yet this year
#         if (today.month, today.day) < (self.dob.month, self.dob.day):
#             age -= 1
#         return age

#     def display(self):
#         """Display the person's details and age."""
#         print(f"Name: {self.name}")
#         print(f"Country: {self.country}")
#         print(f"Date of Birth: {self.dob.strftime('%d-%m-%Y')}")
#         print(f"Age: {self.calculate_age()} years")

# # Example usage
# person = Person()
# person.get_details()
# person.display()









class Person:

    def get_details(self):
        self.name = input("Enter name: ")
        self.country = input("Enter country: ")
        self.dob = input("Enter date of birth (DD-MM-YYYY): ")

    def display(self):
        day, month, year  = map(int, self.dob.split("-"))
        current_day, current_month, current_year = 3, 1, 2025
        age = current_year - year
        if (current_month, current_day) < (month, day):
            age -= 1

        print(f"Name: {self.name}")
        print(f"Country: {self.country}")
        print(f"Date of Birth: {self.dob}")
        print(f"Age: {age} years")

# Example usage
person = Person()
person.get_details()
person.display()





data = {"c": 3, "a": 1, "b": 2, "e": 5, "d": 4}
key= input("Enter the key to remove: ")
del data[key]
print("Dictionary after removal:", data)

sorted_dict = dict(sorted(data.items()))
print("Dictionary sorted by keys:  => ",sorted_dict)


