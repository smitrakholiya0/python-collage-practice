def smite():
    print("hello")