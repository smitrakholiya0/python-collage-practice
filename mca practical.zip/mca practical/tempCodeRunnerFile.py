class Person:

    def get_details(self):
        self.name = input("Enter name: ")
        self.country = input("Enter country: ")
        self.dob = input("Enter date of birth (DD-MM-YYYY): ")

    def display(self):
        day, month, year  = map(int, self.dob.split("-"))
        current_day, current_month, current_year = 3, 1, 2025
        age = current_year - year
        if (current_month, current_day) < (month, day):
            age -= 1

        print(f"Name: {self.name}")
        print(f"Country: {self.country}")
        print(f"Date of Birth: {self.dob}")
        print(f"Age: {age} years")

# Example usage
person = Person()
person.get_details()
person.display()