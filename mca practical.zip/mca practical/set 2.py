# import pickle
# def displayR():
#         with open('players.dat', 'rb') as file:
#             while True:
#                 try:
#                     record = pickle.load(file)
#                     if record[1].startswith('A'):
#                         print(record)
#                 except EOFError:
#                     break  

# def addR(record):
#     with open('players.dat', 'ab') as file:
#         pickle.dump(record, file)

# addR([123, 'AFFFfdlice', 'USA', 5000])
# displayR()




# try:
#     age = int(input("Enter your age: "))
#     assert 18<=age<=40, "age btw 18 to 45"
# except Exception as e:
#     print(e)




import pickle
def addFunction(l1):
    with open("players1.dat", "ab") as add:
         pickle.dump(l1,add)
         

def displayFunction():
    with open("players1.dat","rb") as rd:
        while True:
            try:
                loded = pickle.load(rd)
                if loded[1].startswith("A"):
                    print(loded)
            except:
                break
        

while True:
    val = int(input("enetr 1 for add deatils 2 for show details 3 for exit"))
    if(val==1):
            code= input("enetr code")
            name= input("enter name")
            country= input("enter country")
            total_runs= input("enter total runs")
            l1=[code, name, country, total_runs]
            addFunction(l1)
    elif(val==2):
        displayFunction()
    elif(val==3):
        break
    else:
        print("enter valid input")



