# class Student:

#     def __init__(self):
#         self.list1=[]

#     def addStudentDetails(self,RegNo,StuName,dob,ClgName):
#         d1={
#             "RegNo" : RegNo,
#             "StuName":StuName,
#             "dob" :dob,
#             "ClgName" :ClgName
#         }
#         self.list1.append(d1)

#     def showStudentDetails(self):
#         for v, k in enumerate(self.list1):
#             print(v, k)

# obj= Student()

# while True:
#     v1 = int(input("enter 1 for add, 2 for show, 3 fro exit"))
#     if(v1==1):
#         RegNo = input("enetr regNo")
#         StuName= input("enetr Student name")
#         dob= input("enetr DOB")
#         ClgName= input("enetr collage name")
#         obj.addStudentDetails(RegNo,StuName,dob,ClgName)

#     elif(v1==2):
#         obj.showStudentDetails()

#     elif(v1==3):
#         break
#     else:
#         print("invalid")











class student:
    def __init__(self):
        self.l1=[]
    
    def addStudentDetails(self,rno,sname,dob,cname):
        d1={
            "rno" : rno,
            "sname":sname,
            "dob":dob,
            "cname":cname
        }
        self.l1.append(d1)


    def showStudentDetails(self):
        for item in self.l1:
            print(item)



ob= student()
while True:
    val = int(input("enetr 1 for add deatils 2 for show details 3 for exit"))
    if(val==1):
        rno= input("enetr rollno")
        sname= input("enetr sname")
        dob= input("enetr dob")
        cname= input("enetr cname")
        ob.addStudentDetails(rno,sname,dob,cname)
    elif(val==2):
        ob.showStudentDetails()
    elif(val==3):
        break
    else:
        print("enter valid input")





try:
    with open("smit.txt", "r") as e:
        pass
except Exception as e:
    print("file not found f",e)