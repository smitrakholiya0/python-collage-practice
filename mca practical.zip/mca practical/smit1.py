# main.py

# from smit import smite  # Import the smit function from smit.py

# smite()  # Call the smit function

if __name__ == "__main__":  # Check if this script is the main program
    print("yes")
else:
    print("no")
