class Account:
    def __init__(self):
        self.l1=[]
    
    def addLoanDetails(self, LoanNo, Name,CreditLimit, LoanType, Balance):
        self.LoanNo=LoanNo
        self.Name=Name
        self.CreditLimit= CreditLimit
        self.LoanType=LoanType
        self.Balance=Balance

        d1 ={
            "LoanNo":LoanNo,
            "Name": Name,
            "CreditLimit":CreditLimit,
            "LoanType":LoanType,
            "Balance": Balance
        }

        self.l1.append(d1)


    def showLoanDetails(self):
        for item in self.l1:
            print(item)

obj = Account()

while True:
    choice =int(input("enter choice 1 for add, 2 for show and 3 for exit"))
    if choice ==1:
        LoanNo = input("enter LoanNo")
        Name = input("enter Name")
        CreditLimit = input("enter CreditLimit")
        LoanType = input("enter LoanType")
        Balance = input("enter Balance")
        
        obj.addLoanDetails(LoanNo, Name,CreditLimit, LoanType, Balance)

    elif choice==2:
        obj.showLoanDetails()
    
    elif choice ==3:
        break

    else:
        print("enter valid choice")


# list1= [12, 24, 12, 35, 24, 88, 120, 155, 88, 120, 155]
# ul =[]
# for i in list1:
#     if i in ul:
#         pass
#     else:
#         ul.append(i)

# print(ul)   



# list1 =[12, 24, 35, 24 ,88, 120, 155, 88, 120, 155,88,4]
# el= []

# for i in list1:
#     if i not in el:
#         el.append(i)

# print(el)