class StudentManagementSystem:
    def __init__(self):
        self.students = {}

    def add_student(self, student_id, name):
        self.students[student_id] = name
        print(f"Student {name} added.")

    def display_students(self):
        for student_id, name in self.students.items():
            print(f"ID: {student_id}, Name: {name}")

    def search_student(self, student_id):
        if student_id in self.students:
            print(f"Found: ID: {student_id}, Name: {self.students[student_id]}")
        else:
            print("Student not found.")

    def delete_student(self, student_id):
        if student_id in self.students:
            del self.students[student_id]
            print(f"Student with ID {student_id} deleted.")
        else:
            print("Student not found.")

# Example usage
sms = StudentManagementSystem()
sms.add_student(1, "Alice")
sms.add_student(2, "Bob")
sms.display_students()
sms.search_student(1)
sms.delete_student(2)
sms.display_students()







