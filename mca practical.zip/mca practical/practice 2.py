class Bank:
    def __init__(self):
        # A dictionary to store customer account details
        self.accounts = {}

    def create_account(self, account_number, customer_name, initial_balance=0):
        """Create a new account with an initial balance."""
        if account_number in self.accounts:
            print("Account already exists.")
        else:
            self.accounts[account_number] = {
                'customer_name': customer_name,
                'balance': initial_balance
            }
            print(f"Account for {customer_name} created successfully!")

    def deposit(self, account_number, amount):
        """Deposit money into an account."""
        if account_number in self.accounts:
            if amount > 0:
                self.accounts[account_number]['balance'] += amount
                print(f"Deposited {amount} to account {account_number}.")
            else:
                print("Amount must be greater than zero.")
        else:
            print("Account not found.")

    def withdraw(self, account_number, amount):
        """Withdraw money from an account."""
        if account_number in self.accounts:
            if amount > 0:
                if self.accounts[account_number]['balance'] >= amount:
                    self.accounts[account_number]['balance'] -= amount
                    print(f"Withdrew {amount} from account {account_number}.")
                else:
                    print("Insufficient balance.")
            else:
                print("Amount must be greater than zero.")
        else:
            print("Account not found.")

    def check_balance(self, account_number):
        """Check the account balance."""
        if account_number in self.accounts:
            balance = self.accounts[account_number]['balance']
            print(f"Account Balance for {account_number}: {balance}")
        else:
            print("Account not found.")

# Main Program
def main():
    bank = Bank()

    while True:
        print("\nBank Menu")
        print("1. Create Account")
        print("2. Deposit Money")
        print("3. Withdraw Money")
        print("4. Check Balance")
        print("5. Exit")
        
        choice = input("Enter your choice: ")

        if choice == '1':
            account_number = input("Enter Account Number: ")
            customer_name = input("Enter Customer Name: ")
            initial_balance = float(input("Enter Initial Balance: "))
            bank.create_account(account_number, customer_name, initial_balance)
        
        elif choice == '2':
            account_number = input("Enter Account Number: ")
            amount = float(input("Enter Deposit Amount: "))
            bank.deposit(account_number, amount)
        
        elif choice == '3':
            account_number = input("Enter Account Number: ")
            amount = float(input("Enter Withdrawal Amount: "))
            bank.withdraw(account_number, amount)
        
        elif choice == '4':
            account_number = input("Enter Account Number: ")
            bank.check_balance(account_number)
        
        elif choice == '5':
            print("Exiting the Bank System. Goodbye!")
            break
        
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
