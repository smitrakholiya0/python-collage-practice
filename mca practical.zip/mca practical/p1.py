class Investment:
    def __init__(self, principal, interest_rate):  # Fixed constructor name
        self.principal = principal
        self.interest_rate = interest_rate
 
    def value_after(self, years, compound=False):
        if not compound:
            # Simple Interest formula
            return self.principal * (1 + self.interest_rate * years)
        # Compound Interest formula
        return self.principal * (1 + self.interest_rate) ** years

    def __str__(self):
        # String representation with formatted principal and interest rate
        return f"Principal: ${self.principal:.2f}, Interest Rate: {self.interest_rate * 100:.2f}%"

    def __call__(self, years):
        # Print year-wise simple and compound interest values
        for year in range(1, years + 1):
            simple = self.value_after(year)
            compound = self.value_after(year, True)
            print(f"Year {year}: Simple: ${simple:.2f}, Compound: ${compound:.2f}")

# Take input from user
principal = float(input("Enter the principal amount: "))
interest_rate = float(input("Enter the annual interest rate (as a percentage): ")) / 100
years = int(input("Enter the number of years: "))

# Create Investment object and display results
inv = Investment(principal, interest_rate)
print(inv)  # Print investment details
inv(years)  # Print year-wise results for simple and compound interest
