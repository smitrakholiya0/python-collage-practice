import pickle
# Write contents to file
def write_games(filename, games):
    with open(filename, 'wb') as file:
        for i in games:
            pickle.dump(i, file)

# Read records where game name is "Basket Ball"
def read_basketball_games(filename):
    with open(filename, 'rb') as file:
                game = pickle.load(file)
                for game in games:
                    if game[0] == "Basket Ball":
                        print(game)

# Example usage
games = [['Basket Ball', 10], ['Football', 22], ['Basket Ball',42]]
write_games('game.dat', games)
read_basketball_games('game.dat')

