class Medicine:
    def __init__(self):
        self.drug_list = [] 

    def addDrugDetails(self, product_number, medicine_name, mfg_date, exp_date, company_name):
        drug = {
            "Product Number": product_number,
            "Medicine Name": medicine_name,
            "Manufacturing Date": mfg_date,
            "Expiry Date": exp_date,
            "Company Name": company_name,
        }
        self.drug_list.append(drug)

    def showDrugDetails(self,s1):
        for item in self.drug_list:
            if item["Company Name"]==s1:
                print(item)
            

obj = Medicine()
while True:
    v1 = int(input("enter 1 for add, 2 for show, 3 fro exit"))
    if(v1==1):
        product_number = input("enetr product number")
        medicine_name= input("enetr medicine name")
        mfg_date= input("enetr mfg_date")
        exp_date= input("enetr exp_date")
        company_name= input("enetr company_name")
        obj.addDrugDetails(product_number, medicine_name, mfg_date, exp_date, company_name)

    elif(v1==2):
        s1= input("enetr medicine name")
        obj.showDrugDetails(s1)

    elif(v1==3):
        break
    else:
        print("invalid")


os =input("enter string")
cn=input("enter string to find for replace")
ns = input("enter string to replce")
print("old string is ", os)
os= os.replace(cn,ns)
print("new is",os)


os = "raju is good but ok"
cn = "good"
ns = "bad"

# Split the string into words, replace if match found, and join them back
words = os.split()  # Split the string into words
for i in range(len(words)):
    if words[i] == cn:
        words[i] = ns  # Replace the word
os = " ".join(words)  # Join the words back into a string

print(os)
