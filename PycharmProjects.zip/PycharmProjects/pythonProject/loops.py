items = [12,69,23,24,63,22,45,25]

for item in items:
    if  item>65:
        print(item)