import requests

r = requests.get("https://www.nasa.gov/")
print(r.text)
print(r.status_code)

data={
    "p1":3,
    "p2":4,
    "p3":5
}
url="https://www.nasa.gov/"

r2=requests.post(url=url,data=data)
