f1 = open("smit.txt")
try:
    f = open("smit6.txt")
except Exception as e:
    print(e)

else:
    print("else run")
finally:
    f1.close()
    print("closwd")


print("ene k") 