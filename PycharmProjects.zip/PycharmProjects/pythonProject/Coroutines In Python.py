# def shercher():
#     import time
#     book = "This is a book on harry"
#     time.sleep(3)
#
#     while True:
#         text = (yield)
#         if text in book:
#             print("text in book")
#         else:
#             print("text in not book")
#
#
# sar = shercher()
# next(sar)
# sar.send("harry")
# input("press any key")
# sar.send("ahs")
# sar.close()


def nameSearch():
    import  time
    name = "smit raj vivek raju sahil hemang"
    time.sleep(3)

    while True:
        text = (yield)
        if text in name:
            print("aap ka name he")
        else:
            print("aap ka name nahi hey")

sa = nameSearch()
print("Searching")
next(sa)
sa.send(input("Enter your name"))
sa.send(input("Enter your name"))
sa.send(input("Enter your name"))
# sa.close()
