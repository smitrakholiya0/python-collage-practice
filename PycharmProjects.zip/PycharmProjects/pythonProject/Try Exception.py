from logging import exception

print("enter the value of num1")
num1 = input()
print("enter the value of num2")
num2 = input()
try:
    print("sum is two number is",int(num1)+int(num2))
except exception as e:
    print(e)

print("this is enportant")