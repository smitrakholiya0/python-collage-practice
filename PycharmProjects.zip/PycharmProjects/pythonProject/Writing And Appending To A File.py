# f = open("smit2.txt","a")
# c= f.write("smit is wrriting\n")
# f.close()
# print(c)
f = open("smit2.txt","r+")
print(f.read())
f.write("thank you so much")
f.close()

