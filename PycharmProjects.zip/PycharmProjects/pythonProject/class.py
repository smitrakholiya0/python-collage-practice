class student:
    pass
harry = student()
larry = student()

harry.name= "heri"
harry.salary = 4000
larry.age=42
larry.sub= ["hindi","english","gujarati"]
print(larry.age,larry.sub,harry.salary)