class Employee:
    no_of_leaves = 8

    def __int__(self, aname, asalary, arole):
        self.name = aname
        self.salary = asalary
        self.role = arole

    def printdetails(self):
        return f"name is {self.name} salary = {self.salary} role= {self.role}"




harry = Employee("Harry", 255, "Instructor")
rohan = Employee("Rohan", 455, "Student")
print(harry.salary)