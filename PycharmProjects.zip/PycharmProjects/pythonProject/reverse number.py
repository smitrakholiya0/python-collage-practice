n = int(input("enter number"))

while n>0:
    r= n%10
    print(r,end="")
    n=n//10
