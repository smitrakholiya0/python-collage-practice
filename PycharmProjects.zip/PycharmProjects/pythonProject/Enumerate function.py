li1 =["bhindi", "aloo", "bengaln", "guvar", "kobi"]

for index, item in enumerate(li1):
    if index%2==0:
        print(item)