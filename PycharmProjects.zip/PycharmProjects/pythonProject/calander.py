import calendar

y = int(input("enetr year"))
# ma = int(input("enter month"))

print(calendar.calendar(y))


