print("hello world")
print("sec hello")
# this is comment
""" 
this 
is multiline 
comment
"""
"""
print("c:\\narry\n \tsmit")

#calculater
"""
"""

a= int(input("enter first number"))
b= int(input("enter second number"))
print("addi.=",a+b)
print("subs.=",a-b)
print("multi.=",a*b)
print("divi.=",a/b)

var1= "5"
var2= "4"
print(int(var1) + int(var2))
"""

jio= ["5g", "aazad", "plan", "coding", "last","first", 5]

jio.append(56)
print(jio)
