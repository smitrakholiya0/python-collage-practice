num = int(input("enter number of line star"))
two= int(input("0 or 1"))
new =bool(two)
if new == True:
 for i in range(1,num+1):
     for j in range(1,i+1):
        if(j<=i):
            print("*",end='')
        else:
            print(" ",end='')
     print()
elif new == False:
 for i in range(num,0,-1):
     for j in range(1,i+1):
        if(i<=j):
            print(" ", end='')
        else:
            print("*", end='')

     print()