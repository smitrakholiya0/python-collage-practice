# ls = [i for i in range (100) if i % 2==0 ]
# print(ls)

# dic1 = {i:f"Item{i}" for i in range(1, 5)}
# print(dic1)
#
# dict2 = {key:value for value,key in dic1.items() }
# print(dict2)
#
#
# setv={i for i in ["s","s","s","s","g","t"]}
# print(setv)
# print(type(setv))

# generet = (i for i in range(100) if i%2==0 )
# print(generet.__next__())
# print(generet.__next__())
#
# for i in generet:
#     print(i)

inp = input("input by space")
a= int(input("1 for list, 2 for dic, 3 for set"))
am = inp.split()

if a == 1:
    sf = [i for i in am]
    print(sf)

elif a == 2:
    sf = {f"Items{i}": i for i in am}
    print(sf)

elif a == 3:
    sf = {i for i in am}
    print(sf)

else:
    print("enetr valid")