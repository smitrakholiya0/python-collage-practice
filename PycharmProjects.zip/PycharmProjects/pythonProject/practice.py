def fibonacci_series(n):
    series = [0, 1]  # Initialize the series with the first two numbers

    for i in range(2, n):
        next_num = series[i - 1] + series[i - 2]  # Calculate the next number by summing the previous two
        series.append(next_num)  # Add the next number to the series

    return series



n = 10
result = fibonacci_series(n)

print(fibonacci_series(n))


# def fibonacci(n):
#     if n <= 1:
#         return n
#     else:
#         return fibonacci(n-1) + fibonacci(n-2)
#
# # Test the function by generating the Fibonacci series up to the 10th number
# n = 8
# result = [fibonacci(i) for i in range(n)]
# print(result)
#



#loop
# n = 6  # Number of rows in the pyramid
#
# for i in range(1, n):  # Loop for each row
#     for j in range(1, i):  # Loop to print numbers in each row
#         print(j, end=' ')
#     print()  # Print a new line after each row

# i= 0
# while True:
#     print(i)
#     i+=1