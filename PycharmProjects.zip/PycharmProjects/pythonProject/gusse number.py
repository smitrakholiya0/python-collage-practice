
gt=1
print("number of gusse 5 times")
while(gt<=5):
    num = int(input("enter number"))
    if num<18:
     print("your number",num,"is not valid please gusse up number")
    elif num>18:
     print("your number",num,"is not valid please gusse down number")
    else:
     print("you are win")
     print("game finish")
     break
    print("number of gusses is", 5 - gt ,"left")
    gt=gt+1
if (gt>5):
    print(" you lost chans game over")