import requests
import json
def speakw(pas):
    from win32com.client import Dispatch
    speak = Dispatch("SAPI.SpVoice")
    speak.Speak(pas)

if __name__ == '__main__':

    news = requests.get("https://newsapi.org/v2/top-headlines?country=in&apiKey=18282755a81f4a69b757e07c18f91388").text

    news_dict = json.loads(news)
    jem = (news_dict['articles'])
    for article in jem:
        print(article['title'])
        speakw(article['title'])
        speakw("next news")
