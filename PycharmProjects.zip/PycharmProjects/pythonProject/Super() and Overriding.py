class A:
    classvar = "variable of class a"
    def __init__(self):
        self.var1 = "it is instance of class a's consrutor "
        self.classvar = "instace of class a"
        self.special = "special of a"


class B(A):
    classvar2 = "variable of class b"

    def __init__(self):
        super().__init__()
        self.var1 = "it is instance of class b's consrutor "
        self.classvar = "instace of class b"
        super().__init__()
        print(super().classvar)

a = A()
b = B()
# print(b.special , b.var1 , b.classvar)




