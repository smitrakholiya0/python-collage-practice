# a = input("what is your name")
# b= input("how much do you earn")
# if b == 0:
#     raise ZeroDivisionError("b is zero")
# if a.isnumeric():
#     raise Exception("number is not allowed")
#
# print(f"hello{a}")


c = input("enter your name")
try:
    print(a)
except Exception as e:
    if c == "harry":
        raise ValueError("harry is not allowed")
    print("hendeled")