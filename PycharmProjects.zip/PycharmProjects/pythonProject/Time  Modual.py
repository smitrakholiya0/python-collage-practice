import time
a1 = time.time()
time.sleep(1)
for i in range(3):
    print("train aa gai")
print(time.time() - a1)
a2 = time.time()
k=0
while(k<5):
    print("train aa gai")
    k= k+1
print(time.time() - a2)

tt= time.time()
print(tt)