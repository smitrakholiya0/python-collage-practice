# """map"""
# number = ["2","4","3","5","7","6"]
# number= list(map(int, number))
#
# num = number[2] + number[4]
# print(num)
#
#
# def squre(a):
#     return a*a
# numbers1= [2,3,5,7,9,4,5]
# squre = list(map(squre,numbers1))
# print(squre)

# """map"""
# numbers2= [2,3,5,7,9,4,5]
# def g5(a):
#     return a>5
# numbers2= list(filter(g5, numbers2))
# print(numbers2)

# """reduce"""


list1 = [1,2,3,4,2]
num = reduce(lambda x,y:x*y, list1)
# num = 0
# for i in list1:
#     num = num + i
print(num)
