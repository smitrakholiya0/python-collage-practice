khana = ["roti", "chawal", "sabji", "chhas", "dal"]

for i in khana:

    if i == "chiken":
        break


else:
    print(" this is ready end")