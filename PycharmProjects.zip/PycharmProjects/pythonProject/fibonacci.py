def itr(n):
    if n==0 or n==1:
        return n
    else:
        return  itr(n-1) +itr(n-2)

def recu(n):
    p=0
    c=1
    for i in range(1,n):
        pp = p
        p=c
        c =pp+p
    return c


if __name__ == '__main__':
    num = int(input("enetr number"))
    print(f"by itr{itr(num)} and by recu{recu(num)}")