mystr = "Harry is a good boy"
# print(len(mystr))
# print(mystr[::-2])
"""
print(mystr.endswith("bdoy"))
print(mystr.count("o"))
print(mystr.capitalize())
print(mystr.replace("is", "are"))
"""
# String Functions:

demo = "Aakash is a good boy"
print(demo.endswith("boy"))
print(demo.count('o'))
print(demo.capitalize())
print(demo.upper())
print(demo.lower())
print(demo.find("is"))
print(demo.find("good","nice"))
