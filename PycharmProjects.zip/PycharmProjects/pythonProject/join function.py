l1= ["raju", "milabn", "sauth", "hero","arjun","drona"]


# for item in l1:
#     print(item, "and", end=" ")

a= " and ".join(l1)
print(a)