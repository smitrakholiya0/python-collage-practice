print("WELCOME TO LOVE BOAT... \n")
m= input("how can i help you???")
a = input("You are in relationship?\n")

if a == "yes":
    b = input("LOVE AI BOAT: Do you feel that your gf cheats and lies with you?\n")
    if b == "yes sometime":
        c = input("LOVE AI BOAT: your gf have a best friend?\n")
        if c == "yes many":
            print("LOVE AI BOAT: please care of her, because high chance of best friend is to be boy friend\n")
            d = input("LOVE AI BOAT: What time does your gf go to bed?\n")
            if d == "1am":
                e = input("LOVE AI BOAT: vo to aap ko bolti hongi 1 baje k bad dusre bf k sath bate karti hongi ek bar jag k check kar lena\n")
                if e== "nahi bharosa he meri gf par":
                   print("LOVE AI BOAT: are bhai ye hi bharosa ek bar tera chutiya kat lenga ise achchha he ki jyada bharosa karna chhod de\n")


            else:
                print("ok")
        else:
            print("ok")
    else:
        print("wow!!! but, carefull")
else:
    print("You are lucky... try to impress girl ")