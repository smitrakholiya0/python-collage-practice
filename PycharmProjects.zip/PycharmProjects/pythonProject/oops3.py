# class Employee:
#     liv= 5
#     def __init__(self, aname, asalary, aage):
#         self.name= aname
#         self.salary= asalary
#         self.age= aage
#
#     def o1(self):
#         return f"name is {self.name} salary is {self.salary} age is {self.age} "
#
#     @classmethod
#     def change_leave(cls, newlv):
#         cls.liv= newlv
#
#
# harry = Employee("harry", 600000, 17)
# # larry = Employee()
# # harry.salary= 400000
# # larry.salary= 5000000
# # harry.name= "heri"
# # larry.name= "larry"
# # harry.age= 14
# # larry.age=19
#
# print(harry.o1())
# harry.change_leave(10)
# print(harry.liv)
class K:
    def disk(self):
        print("kk")
class A:
    def dispa(self):
        print("perent")
class B(A):
    def dispb(self):
        print("single")
class C(B):
    def dispc(self):
        print("multilevel")
class D(A,K):
    def dispd(self):
        print("multiple")

ob = D()
ob1 =
ob.dispa()
ob1.dispb()
ob2.dispc()
ob.dispd()

