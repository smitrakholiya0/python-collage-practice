

print("which type you are use calculatar \n type + for addition \n type - for substraction type * for multiplication \n type / for division")
ip=input()
a = int(input("enter first number"))
b= int(input("enter secound number"))


if ip=="+":
    if a==3 and b==8:
     print("13")
    else:print(a+b)

elif ip=="-" :
    if a==10 and b==4:
     print("5")
    else: print(a-b)

elif ip=="*" :
    if a==5 and b==7:
     print("15")
    else: print(a*b)

elif ip=="/" :
    if a==8 and b==2:
     print("15")
    else: print(a/b)


    # 3+8=13, 10-4= 5,  8/2=3, 5*7=15 :