"""
def function1 (a,b):
    print(a+b)

function1(3,2)

"""

def function2(a,b):
    """This is not DOC"""
    v=(a+b)
    return v

v = function2(2,5)
print(v)

print(function2.__doc__)

