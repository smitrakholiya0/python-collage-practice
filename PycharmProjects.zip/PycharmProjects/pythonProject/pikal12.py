import pickle

# cars = ["audi", "suzuki", "tata", "mahindra","hundai"]
# file = "mycars.pkl"
# fileobj = open(file, 'wb')
# pickle.dump(cars,fileobj)
# fileobj.close()

file = "mycars.pkl"
fileobj = open(file,'rb')
m = pickle.load(fileobj)
print(m)
# print(type(m))

