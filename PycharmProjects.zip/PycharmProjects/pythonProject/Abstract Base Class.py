# from abc import ABC, abstractmethod
from abc import ABCMeta, abstractmethod

class Shape(metaclass=ABCMeta):
    @abstractmethod
    def recta(self):
        return 0

class Rancangl(Shape):

    def __init__(self):
        self.h1 = 5
        self.w1 = 10

    def recta(self):
        return self.h1 * self.w1


class Sec(Shape):
    def __init__(self):
        self.h1 = 10
        self.w1 = 20
    def recta(self):
        return self.h1 * self.w1

    print("all is well")


em = Rancangl()
se = Sec()
print(em.recta())
print(se.recta())


