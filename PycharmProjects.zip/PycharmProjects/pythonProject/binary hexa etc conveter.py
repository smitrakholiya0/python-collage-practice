n = int(input("Enter number"))

print(f"binary is {bin(n)}")
print(f"octal is {oct(n)}")
print(f"hexadecimal is {hex(n)}")
