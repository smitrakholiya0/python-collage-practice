class A:
    def metal(self):
        print("This is property of class A")

class B(A):
    def metal(self):
        print("This is property of class B")

class C(A):
    def metal(self):
        print("This is property of class C")

class D(B ,C):
    def metal(self):
        print("This is property of class D")


a = A()
b = B()
c = C()
d = D()


d.metal()
