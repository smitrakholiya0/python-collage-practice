def recu(n):
    if n==0 or n==1:
        return n
    else:
        return n * recu(n-1)

def imit(n):
    fac=1
    while(n>0):
        fac = fac* n
        n=n-1
    return fac

if __name__ == '__main__':
    num= int(input("enetr number"))
    print(f"print by recuson {recu(num)}   and print by immit{imit(num)}")

