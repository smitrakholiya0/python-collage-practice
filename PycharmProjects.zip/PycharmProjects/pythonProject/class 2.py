class Employee:
    toliv =5
    pass

harry = Employee()
larry = Employee()

harry.salary= 400000
larry.salary= 5000000
harry.name= "heri"
larry.name= "larry"
harry.age= 14
larry.age=19

print("live=",Employee.toliv)

Employee.toliv = 10
print(Employee.toliv)
print(harry.__dict__)
harry.toliv= 50
print(harry.__dict__)
