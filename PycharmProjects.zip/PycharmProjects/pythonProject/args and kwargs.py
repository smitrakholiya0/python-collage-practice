def function1(normal1,*args,**c12):
    print(args)
    print(type(args),"\n") #known type of variable
    print(normal1)
    for i , m in c12.items():
        print(i,m)
s1 = ["smit", "harry", "rahul", "heet", "sahil"]
jk = ["noraml chhe"]
cwad = {"smit":"idali", "raju":"dhosa", "kevin":"eggs", "samir":"banana"}

function1(jk,*s1,**cwad)
