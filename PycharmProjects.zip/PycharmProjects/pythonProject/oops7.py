class Dad:
    basketball = 1


class Sun(Dad):
    gitar = 2
    dance = 6


class Grandsun(Sun):
    d = 3



print(Grandsun.basketball)