class Employee:
    liv= 5
    def __init__(self, aname, asalary, aage):
        self.name= aname
        self.salary= asalary
        self.age= aage

    def o1(self):
        return f"name is {self.name} salary is {self.salary} age is {self.age} "

    @classmethod
    def clve(cls,newle):
        cls.liv=newle

    @classmethod
    def ch1(cls, string):
        # kp = string.split("-")
        # return cls(kp[0],kp[1],kp[2])
        return cls(*string.split("-"))

    @staticmethod
    def strm(string):
        print("it is good",string)
        return  string
harry = Employee("harry", 600000, 17)
harry.clve(7)
larry = Employee.ch1("larry-50000- 17")
print(harry.o1())
print(harry.liv)
print(larry.salary)
harry.strm("hii")


# larry = Employee()
# harry.salary= 400000
# larry.salary= 5000000
# harry.name= "heri"
# larry.name= "larry"
# harry.age= 14
# larry.age=19
