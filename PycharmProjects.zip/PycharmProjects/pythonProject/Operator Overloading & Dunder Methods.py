class Employee:
    liv= 5
    def __init__(self, aname, asalary, aage):
        self.name= aname
        self.salary= asalary
        self.age= aage

    def printde(self):
        return f"name is {self.name} salary is {self.salary} age is {self.age} "

    @classmethod
    def change_leave(cls, newlv):
        cls.liv= newlv

    def __add__(self, other):
        return self.salary + other.salary


emp1 = Employee("harry", 250, "programer")
emp2 = Employee("jerry", 40, "clener")
# emp3 = Employee("kerry", 50, "memer")
print(emp1+emp2)



