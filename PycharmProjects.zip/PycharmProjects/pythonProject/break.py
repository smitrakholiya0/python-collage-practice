"""
i=0
while(i<45):
    print(i)
    i= i+1

i=0
while(1):
    if i==15:
        break
    print(i)
    i= i+1

"""


i=0
while(1):
    a = int(input("enter number"))
    if a>100:
        print(("congrats"))
        break
    else:
         print("try agian")
         continue











