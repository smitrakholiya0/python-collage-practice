d1 = {
  "smit" : "omlet",
  "umang" : "banana",
  "raju" : "chiken",
  "kavya" : "sandwich",
  "sudarshan" : "pizza"
}
b = input("enter name")

print("is eat",d1[b])