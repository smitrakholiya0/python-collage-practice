# a= "smit"
# m= "89"
# b= "first good boy of the world is %s so %s it" %(m,a)
# print(b)

# a= "is "
# b= "bot"
# c= 34
# # d= f" this {a} a {b} type"
# # print(d)
# print(f"this {a} a {b} type and its value is {c}")



