import random
a= random.randint(0,5)
print(a)

rand = random.random() *100
print(rand)

lst = ["smit", "harry","umang", 5, "meet","rahul",4]
choice = random.choice(lst)
print(choice)

