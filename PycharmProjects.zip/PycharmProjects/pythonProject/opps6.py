class Employee:
    liv = 5
    var = 9
    def __init__(self, aname, asalary, arole):
        self.name = aname
        self.salary = asalary
        self.role = arole

    def o1(self):
        return f"name is {self.name} salary is {self.salary} age is {self.role}"

    @classmethod
    def clve(cls, newle):
        cls.liv = newle

    @classmethod
    def ch1(cls, string):
        # kp = string.split("-")
        # return cls(kp[0],kp[1],kp[2])
        return cls(*string.split("-"))

    @staticmethod
    def strm(string):
        print("it is good", + string)

class Player:
    var = 10
    no_of_game = 4
    def __init__(self , name , game):
        self.name = name
        self.game = game

    def printde(self):
        return f"name is {self.name} game is {self.game}"

class Cool_programmer(Employee, Player):
    language = "c++"
    # var = 20
    def printlangu(self):
        print(self.language)

harry = Employee("harry", 600000, 17)
larry = Employee.ch1("larry-50000- 17")
shubham = Player("karan", ["cricket"])

karan = Cool_programmer("karan", 4444999, "cool programer")

print(karan.var)
