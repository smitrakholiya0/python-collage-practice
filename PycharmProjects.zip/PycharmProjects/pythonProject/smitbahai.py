import json


data12 = '{"var1":"harry", "var2":56}'
print(data12)


pasrsedm = json.loads(data12)
print(pasrsedm)
print(pasrsedm["var1"])

data2 = {
    "channel_name": "CodeWithHarry",
    "cars": ['bmw', 'audi a8', 'ferrari'],
    "fridge": ('roti', 540),
    "isbad": False
}

jscomp = json.dumps(data2)
print(jscomp)

