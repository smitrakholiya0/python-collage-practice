import time
from functools import lru_cache

@lru_cache(maxsize=2)
def som(n):
    time.sleep(n)
    return n

if __name__ == '__main__':
    print("hello")
    som(3)
    print("after 3")
    som(4)
    print("4 sec")
    som(3)
    print("after again 3")
    som(2)
    print("again 2")
