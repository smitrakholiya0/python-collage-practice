class Employee:
    def __init__(self, fname, lname):
        self.fname = fname
        self.lname = lname
        self.email = f"{self.fname}{self.lname}@smitrakholiya.com"


    # def explain(self):
    #     return f"The employee is {self.fname} {self.lname}"

    @property
    def emailn(self):
        if self.fname==None or self.lname == None:
            return "not set"

        return f"{self.fname}{self.lname}@smitrakholiya.com"

    @emailn.setter
    def emailn(self,string):
        name = string.split("@")[0]
        self.fname = name.split(".")[0]
        self.lname = name.split(".")[1]

    @emailn.deleter
    def emailn(self):
        self.fname = None
        self.lname = None

hindustani_supporter = Employee("hindustani","supporter")
# nikhil_raj_pande = Employee("nikhil","rajpande")

print(hindustani_supporter.emailn)

hindustani_supporter.fname = "us"


print(hindustani_supporter.emailn)
hindustani_supporter.emailn ="this.that@gmail.com"
print(hindustani_supporter.emailn)
print(hindustani_supporter.fname)

del hindustani_supporter.emailn

print(hindustani_supporter.emailn)