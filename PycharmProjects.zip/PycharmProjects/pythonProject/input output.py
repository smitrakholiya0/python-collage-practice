f= open("smit.txt", "r") #b
# fun = f.read() #f.read(4546)
# #print(fun)
# for line in fun:
#     print(line)
# print(f.readline())
print(f.readlines())
f.close()