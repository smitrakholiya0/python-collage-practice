class Employee:
    liv = 5

    def __init__(self, aname, asalary, arole):
        self.name = aname
        self.salary = asalary
        self.role = arole

    def o1(self):
        return f"name is {self.name} salary is {self.salary} age is {self.age}"

    @classmethod
    def clve(cls, newle):
        cls.liv = newle

    @classmethod
    def ch1(cls, string):
        # kp = string.split("-")
        # return cls(kp[0],kp[1],kp[2])
        return cls(*string.split("-"))

    @staticmethod
    def strm(string):
        print("it is good", + string)


class Programmer(Employee):
    liv = 5
    def __init__(self, aname, asalary, aroal, alanguage):
        self.name = aname
        self.salary = asalary
        self.roal = aroal
        self.language = alanguage

    def printop(self):
        return f"the programer name is {self.name} salary = {self.salary} roal= {self.roal} languages= {self.language} "


harry = Employee("harry", 600000, 17)
larry = Employee.ch1("larry-50000- 17")
subham = Programmer("subham", 2300000, 12, ["python"])
print(larry.salary)

print(subham.printop())















