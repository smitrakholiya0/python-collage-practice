import re

text = "nnfdg12:22:33rfvfrb gresggregggb wfef02:12:11grgrrgger"
pattern = r'(?<!\d)(?:[01]?\d|2[0-3]):[0-5]\d:[0-5]\d(?!\d)'

matches = re.findall(pattern, text)
print(matches)
