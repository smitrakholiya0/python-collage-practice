import pandas as pd

# Load CSV file
df = pd.read_csv("student_scores.csv")

# Display summary statistics
print("Summary Statistics:")
print(df.describe(include='all'))

# Calculate minimum score
min_score = df['score'].min()
print(f"\nMinimum Score: {min_score}")

# Find student with highest total score
# Assuming one score per student
top_student = df[df['score'] == df['score'].max()]
print("\nStudent with Highest Score:")
print(top_student)

# Filter students with scores above 90
high_scorers = df[df['score'] > 90]
print("\nStudents with Score > 90:")
print(high_scorers)
