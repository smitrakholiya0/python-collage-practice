import re

test = "This is my phone number 784-784-9654 and this is my dads number 78454-78456 and this is my moms number 7845123690"

pattern = r'\b(\d{3}-\d{3}-\d{4}|\d{5}-\d{5})\b'

matches = re.findall(pattern, test)
print(matches)
