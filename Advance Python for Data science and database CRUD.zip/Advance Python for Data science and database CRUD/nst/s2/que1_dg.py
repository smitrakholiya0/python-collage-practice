import pandas as pd

# Load CSV file
df = pd.read_csv("employee_data.csv", parse_dates=['join_date'])

# Display last 5 rows
print("\nLast 5 Rows:")
print(df.tail())

# Find max salary
max_salary = df['salary'].max()
print(f"\nMaximum Salary: {max_salary}")

# Total number of rows and columns
rows, cols = df.shape
print(f"\nTotal Rows: {rows}, Total Columns: {cols}")

# Filter employees joined after a specific date
specific_date = pd.to_datetime('2022-01-01')
filtered_df = df[df['join_date'] > specific_date]
print(f"\nEmployees who joined after {specific_date.date()}:")
print(filtered_df)
