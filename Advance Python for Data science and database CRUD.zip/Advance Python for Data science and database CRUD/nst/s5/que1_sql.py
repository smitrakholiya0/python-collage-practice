import mysql.connector

# Establish connection
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="your_password"
)
cursor = conn.cursor()

# Create database
cursor.execute("CREATE DATABASE IF NOT EXISTS MusicStore")
cursor.execute("USE MusicStore")

# Create table
cursor.execute("""
CREATE TABLE IF NOT EXISTS Albums (
    id INT PRIMARY KEY,
    title VARCHAR(100),
    artist VARCHAR(100),
    genre VARCHAR(50)
)
""")

# Insert function
def insert_album(id, title, artist, genre):
    query = "INSERT INTO Albums (id, title, artist, genre) VALUES (%s, %s, %s, %s)"
    cursor.execute(query, (id, title, artist, genre))
    conn.commit()

# Update function
def update_album(id, new_title):
    query = "UPDATE Albums SET title = %s WHERE id = %s"
    cursor.execute(query, (new_title, id))
    conn.commit()

# Delete function
def delete_album(id):
    query = "DELETE FROM Albums WHERE id = %s"
    cursor.execute(query, (id,))
    conn.commit()

# Example usage:
insert_album(1, "Thriller", "Michael Jackson", "Pop")
update_album(1, "Thriller (Remastered)")
delete_album(1)

# Close connection
cursor.close()
conn.close()
