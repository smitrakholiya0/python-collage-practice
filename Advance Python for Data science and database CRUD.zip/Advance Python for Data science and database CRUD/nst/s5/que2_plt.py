import matplotlib.pyplot as plt
import pandas as pd

# Sample data
dates = pd.date_range(start="2022-01-01", periods=30)
prices = [100.50, 102.30, 98.20, 101.45, 105.80, 103.90, 106.00, 107.50,
          108.30, 104.90, 102.75, 101.10, 100.00, 99.50, 98.90, 97.75,
          96.50, 95.60, 94.80, 93.70, 94.00, 95.20, 96.80, 98.90,
          100.20, 102.50, 104.00, 105.50, 103.75, 105.80]

# Plot
plt.figure(figsize=(10, 5))
plt.plot(dates, prices, marker='o', linestyle='-')
plt.xlabel("Date")
plt.ylabel("Stock Price")
plt.title("Stock Prices Over Time")
plt.grid(True)
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()
