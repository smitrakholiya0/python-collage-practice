import mysql.connector

def connect_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="your_password",  # Replace with your MySQL root password
        database="school"
    )

def create_database():
    conn = mysql.connector.connect(host="localhost", user="root", password="your_password")
    cursor = conn.cursor()
    cursor.execute("CREATE DATABASE IF NOT EXISTS school")
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS school.teachers (
            id INT PRIMARY KEY,
            name VARCHAR(100),
            subject VARCHAR(100)
        )
    """)
    conn.commit()
    conn.close()

def insert_teacher():
    conn = connect_db()
    cursor = conn.cursor()
    id = int(input("Enter ID: "))
    name = input("Enter Name: ")
    subject = input("Enter Subject: ")
    cursor.execute("INSERT INTO teachers (id, name, subject) VALUES (%s, %s, %s)", (id, name, subject))
    conn.commit()
    conn.close()
    print("Record inserted.")

def view_teachers():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM teachers")
    for row in cursor.fetchall():
        print(row)
    conn.close()

def update_teacher():
    conn = connect_db()
    cursor = conn.cursor()
    id = int(input("Enter ID to update: "))
    name = input("Enter new Name: ")
    subject = input("Enter new Subject: ")
    cursor.execute("UPDATE teachers SET name=%s, subject=%s WHERE id=%s", (name, subject, id))
    conn.commit()
    conn.close()
    print("Record updated.")

def delete_teacher():
    conn = connect_db()
    cursor = conn.cursor()
    id = int(input("Enter ID to delete: "))
    cursor.execute("DELETE FROM teachers WHERE id=%s", (id,))
    conn.commit()
    conn.close()
    print("Record deleted.")

def menu():
    create_database()
    while True:
        print("\n--- Menu ---")
        print("1. Insert")
        print("2. View")
        print("3. Update")
        print("4. Delete")
        print("5. Exit")
        choice = int(input("Enter your choice: "))
        if choice == 1:
            insert_teacher()
        elif choice == 2:
            view_teachers()
        elif choice == 3:
            update_teacher()
        elif choice == 4:
            delete_teacher()
        elif choice == 5:
            break
        else:
            print("Invalid choice")

menu()
