import matplotlib.pyplot as plt

scores = [85, 90, 75, 80, 95, 88, 92, 70, 82, 78, 86, 94, 87, 91, 84]

# Plotting the histogram
plt.hist(scores, bins=[70, 75, 80, 85, 90, 95, 100], edgecolor='black')

# Labeling
plt.title('Histogram of Student Scores')
plt.xlabel('Score Ranges')
plt.ylabel('Frequency')
plt.grid(True)

# Show the plot
plt.show()
