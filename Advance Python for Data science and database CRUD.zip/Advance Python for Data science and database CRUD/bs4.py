# SET – B, Practical – 4
# Q. No. 1 [15 Marks]
# Write a Python program to implement database connectivity and perform the following CRUD operations.
# Table: Courses
# Fields:
# id (int), name (varchar), instructor (varchar), duration (int)
# CRUD Operations:
# Create a new course.
# Update the instructor where course is ‘Python’.

import mysql.connector

# Connect to the database
connection = mysql.connector.connect(
    host='localhost',  
    database='exam_11',  
    user='root',  
    password=''  
)

cursor = connection.cursor()

# Create the Courses table if it doesn't exist
cursor.execute("""
CREATE TABLE IF NOT EXISTS Courses_11 (
    id INT PRIMARY KEY, 
    name VARCHAR(255),
    instructor VARCHAR(255),
    duration INT
);
""")
connection.commit()

# Function to create a new course
def create_course():
    course_id = int(input("Enter course ID: "))  
    name = input("Enter course name: ")
    instructor = input("Enter instructor name: ")
    duration = int(input("Enter course duration (in hours): "))

    query = "INSERT INTO Courses_11 (id, name, instructor, duration) VALUES (%s, %s, %s, %s)"
    cursor.execute(query, (course_id, name, instructor, duration))
    connection.commit()

    print("Course created successfully.")

# Function to update the instructor where course is 'Python'
def update_instructor():
    course_id = int(input("Enter course ID: "))  
    new_instructor = input("Enter new instructor name: ")
    query = "UPDATE Courses_11 SET instructor = %s WHERE name = '%s'"
    cursor.execute(query, (new_instructor,course_id))
    connection.commit()

    if cursor.rowcount > 0:
        print("Instructor updated successfully.")
    else:
        print("Course 'Python' not found.")

        
while True:
        print("\n----- Courses Management System -----")
        print("1. Create New Course")
        print("2. Update Instructor for Python Course")
        print("3. Exit")

        choice = input("Enter your choice (1-3): ")

        if choice == '1':
            create_course()
        elif choice == '2':
            update_instructor()
        elif choice == '3':
            print("Exiting program.")
            break
        else:
            print("Invalid choice. Please try again.")

cursor.close()
connection.close()



# Q. No. 2 [10 Marks]
# Perform DataFrame Operations on Sales Data
# Operations:
# Read a CSV file containing sales data into a DataFrame:
# [ProductName, Category, Amount]
# Provide the highest sales amount per month.
# Provide all statistical data on sales.


import pandas as pd

# Read CSV file into DataFrame
df = pd.read_csv("bs4.csv", parse_dates=["Date"])

# Add a Month column for grouping
df['Month'] = df['Date'].dt.to_period('M')

# 1. Highest sales amount per month
highest_sales = df.groupby('Month')['Amount'].max()
print("Highest Sales Amount Per Month:\n", highest_sales)

# 2. All statistical data on sales
stats = df['Amount'].describe()
print("\nStatistical Data on Sales:\n", stats)
