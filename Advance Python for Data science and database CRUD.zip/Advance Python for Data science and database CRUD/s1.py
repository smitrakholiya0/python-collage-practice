# SET – 1
# Q. No. 1 [15 Marks]
# Create a MySQL database named student_db and a table student with fields:
# id, name, age, grade.

# Write a menu-driven program to:
# Insert student records.
# Retrieve and display all students.
# Update a student’s grade.
# Delete a student record.


# import mysql.connector 

# conn = mysql.connector.connect(host="localhost", user="root", password="")
# cursor = conn.cursor()

# cursor.execute("create database if not exists student_db")
# cursor.execute("use student_db")

# cursor.execute("""
#                create table if not exists student_11(
#                id int primary key,
#                name varchar(20),
#                age int,
#                grade varchar(5)
#                )
#                """)

# def insert_student():
#     id = int(input("Enter ID: "))
#     name = input("Enter Name: ")
#     age = int(input("Enter Age: "))
#     grade = input("Enter Grade: ")
#     cursor.execute("insert into student_11(id, name, age, grade) values(%s,%s,%s,%s)",(id,name,age,grade))
#     conn.commit() 
#     print("Student inserted successfully.\n")

# def display_students():
#     cursor.execute("select * from student_11")
#     rows = cursor.fetchall()
#     if rows:
#         for row in rows:
#             print(row)
#     else:
#         print("No Rows Found")

# def update_grade():
#     id = int(input("Enter Student ID to update grade: "))
#     grade = input("Enter new grade: ")
#     cursor.execute("update student_11 set grade= %s where id = %s",(grade,id))
#     conn.commit()
#     print("Grade updated successfully.\n")

# def delete_student():
#     id = int(input("Enter Student ID to delete: "))
#     cursor.execute("delete from student_11 where id = %s",(id,))
#     conn.commit()
#     print("Student deleted successfully.\n")


# while True:
#     print("===== Student Menu =====")
#     print("1. Insert Student")
#     print("2. Display All Students")
#     print("3. Update Student Grade")
#     print("4. Delete Student")
#     print("5. Exit")
#     choice = input("Enter your choice (1-5): ")

#     if choice == '1':
#         insert_student()
#         pass
#     elif choice == '2':
#         display_students()
#         pass
#     elif choice == '3':
#         update_grade()
#         pass
#     elif choice == '4':
#         delete_student()
#         pass
#     elif choice == '5':
#         break
#     else:
#         print("Invalid choice. Try again.\n")





# Q. No. 2 [15 Marks]
# Create a CSV file sales.csv containing:
# Product, Sales, Profit, Region.
# Perform the following operations using Pandas:
# Display total sales per product.
# Find the region with the highest sales.
# Filter products where profit is negative.
# Sort sales data by profit in descending order.


# import pandas as pd

# df = pd.read_csv("s1.csv")

# total_sales= df.groupby("Product")["Sales"].sum() 
# print("Total Sales per Product:\n", total_sales, "\n")

# region_sales= df.groupby("Product")["Sales"].sum() 
# highest_region = region_sales.idxmax()
# print("Region with the highest sales:", highest_region, "\n")

# negative_profit= df[df["Profit"]<0]
# print("Products with negative profit:\n", negative_profit, "\n")

# sorted_by_profit= df.sort_values(by="Profit",ascending=False)
# print("Sales data sorted by profit (descending):\n", sorted_by_profit)


