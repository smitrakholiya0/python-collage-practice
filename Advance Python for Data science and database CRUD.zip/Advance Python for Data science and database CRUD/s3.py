# SET – 3
# Q. No. 1 [15 Marks]
# Create movies.csv containing:
# Title, Genre, Rating, Revenue
# Find the highest-grossing movie.
# List all movies with a rating above 8.
# Group movies by genre and count the number of movies per genre.
# Create a bar chart showing revenue by genre.


import pandas as pd
import matplotlib.pyplot as plt

# Load the data
df = pd.read_csv("s3.csv")

# 1. Highest-grossing movie by genre
highest_grossing = df.loc[df.groupby('Genre')['Revenue'].idxmax()]
print("Highest-Grossing Movie by Genre:")
print(highest_grossing)

# 2. List all movies with a rating above 8
high_rated = df[df['Rating'] > 8]
print("\nMovies with rating above 8:")
print(high_rated)

# 3. Group movies by genre and count
genre_counts = df['Genre'].value_counts()
print("\nNumber of movies per genre:")
print(genre_counts)

# 4. Bar chart: Revenue by genre
genre_revenue = df.groupby('Genre')['Revenue'].sum()
genre_revenue.plot(kind='bar', title='Total Revenue by Genre', ylabel='Revenue')
plt.tight_layout()
plt.show()




# # Q. No. 2 [15 Marks]
# # Create a MySQL database with a patients table containing:
# # ID, Name, Age, Disease, Admission_Date
# # Implement CRUD operations:
# # Add new patient ecords.
# # Retrieve patient details based on disease.
# # Update patient details.
# # Delete discharged patient records.

# import mysql.connector

# # Connect once at the top
# connection = mysql.connector.connect(
#     host='localhost',
#     database='exam_11',
#     user='root',
#     password=''
# )
# cursor = connection.cursor()

# # Create the correct table
# cursor.execute("""
# CREATE TABLE IF NOT EXISTS patients (
#     ID INT PRIMARY KEY,
#     Name VARCHAR(100),
#     Age INT,
#     Disease TEXT,
#     Admission_Date DATE
# );
# """)

# # 1. Add new patient
# def add_patient():
#     id = int(input("Enter patient ID to update: "))
#     name = input("Enter name: ")
#     age = int(input("Enter age: "))
#     disease = input("Enter disease: ")
#     admission_date = input("Enter admission date (YYYY-MM-DD): ")

#     query = "INSERT INTO patients (ID, Name, Age, Disease, Admission_Date) VALUES (%s, %s, %s, %s, %s)"
#     values = (id, name, age, disease, admission_date)
#     cursor.execute(query, values)
#     connection.commit()
#     print("Patient added successfully.")

# # 2. Get patients by disease
# def get_patients_by_disease():
#     disease = input("Enter disease to search: ")

#     query = "SELECT * FROM patients WHERE Disease = %s"
#     cursor.execute(query, (disease,))
#     results = cursor.fetchall()
#     if results:
#         for row in results:
#             print(row)
#     else:
#         print("No patients found with that disease.")

# # 3. Update patient
# def update_patient():
#     id = int(input("Enter patient ID to update: "))
#     print("Leave a field blank to skip updating it.")
#     name = input("New name: ")
#     age_input = input("New age: ")
#     disease = input("New disease: ")

#     if name:
#         cursor.execute("UPDATE patients SET Name = %s WHERE ID = %s", (name, id))
#     if age_input:
#         age = int(age_input)
#         cursor.execute("UPDATE patients SET Age = %s WHERE ID = %s", (age, id))
#     if disease:
#         cursor.execute("UPDATE patients SET Disease = %s WHERE ID = %s", (disease, id))

#     connection.commit()
#     print("Patient updated successfully.")

# # 4. Delete patient
# def delete_patient():
#     id = int(input("Enter patient ID to delete: "))
#     cursor.execute("DELETE FROM patients WHERE ID = %s", (id,))
#     connection.commit()
#     print("Patient deleted successfully.")

# # Menu Loop
# while True:
#     print("\n----- Patient Management System -----")
#     print("1. Add Patient")
#     print("2. View Patients by Disease")
#     print("3. Update Patient")
#     print("4. Delete Patient")
#     print("5. Exit")

#     choice = input("Enter your choice (1-5): ")

#     if choice == '1':
#         add_patient()
#     elif choice == '2':
#         get_patients_by_disease()
#     elif choice == '3':
#         update_patient()
#     elif choice == '4':
#         delete_patient()
#     elif choice == '5':
#         print("Exiting program.")
#         break
#     else:
#         print("Invalid choice. Please try again.")

# # Close connection after exit
# cursor.close()
# connection.close()
