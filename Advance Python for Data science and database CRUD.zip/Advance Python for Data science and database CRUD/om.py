#Operations on DataFrame
import pandas as pd

#read
df=pd.read_csv("D:\SVGU MCA SEM-2\Adv. Python\Programs\student_csv.csv")
#print(df)
#Property
#1.shape - no. of rows and columns
#print(df.shape)

r,c =df.shape
#print("No. of Rows:",r)
#print("No. of Columns:",c)

#2. Columns - get all the columns
#print(df.columns)

#3. loc - locate property (find the record)
#print(df.loc['Bigy']) #name - index

#4. index 
#Methods
#1.head - display first 5 rows
#print(df.head())
#print(df.head(10))#first 10 rows

#2.tail - display last 5 rows
#print(df.tail())
#print(df.tail(3))#last 3 rows

#3. sort_values(by=column,ascending=True)
df_sort=df.sort_values(by='mark',ascending=False) #descending order
#print(df_sort)

#4. max(), min() - numerical values
#print("highest Mark:",df['mark'].max())

#5. describe() - displays statistical information
#print(df.describe())

#6. set_index() - 
df.set_index('name',inplace=True)
print("Set index \n",df)

#7. index - property to get index values and information
#print(df.index)
#print(df.loc[12])   #id- index

#8.reset_index()
#df.reset_index(inplace=True)
#print("reset index \n",df)

#handling missing values

#9.fillna() - fill NaN value
#print(df)
#df1=df.fillna(0)
#print(df1)

#df1=df.fillna({'name':'unknown',   'gender':'undefined',                  'mark':12,'class':'unassign'})
#print(df1)

#10.dropna() - delete missing value record
#df1=df.dropna()
#print(df1)

#getting particular columns
#single column
#print(df['name'])
#print(df.mark)

#mutliple columns
#print(df[['name','mark']])

#slicing [start:stop:step]
#print(df[5:10]) #5th row to 9th row

#print(df[20:15:-1]) #reverse

#print(df[1:10:2]) #alternative rows

#print(df[::2])

#queries

#get the student record with highest mark
#print("student with highest mark:")
#print(df[df.mark==df.mark.max()])

#get the student record with lowest mark
#print("student with lowest mark:")
#print(df[df.mark==df.mark.min()])

#student with less than 20 mark
#print(df[df.mark<20])

#student with more than 40 mark
#print(df[df.mark>40])

#student class is Four
#print(df[df['class']=="Four"])

#get male students
#print(df['gender'][df.gender=='male'])
#print(df[['id','gender']][df.gender=='male'])

#display records whose having NaN






















