# SET – B, Practical – 3
# Q. No. 1 [15 Marks]
# Write a Python program to implement database connectivity and perform the following CRUD operations.
# Table: Inventory
# Fields:
# id (int), product_id (int), quantity (int)
# CRUD Operations:
# Add a new inventory item.
# Fetch all inventory items.



# import mysql.connector

# # Connect to the database
# connection = mysql.connector.connect(
#     host='localhost',  # Your MySQL server address (localhost for local machine)
#     database='exam_11',  # The database you want to connect to
#     user='root',  # MySQL username
#     password=''  # MySQL password
# )

# cursor = connection.cursor()

# # Create the Inventory table if it doesn't exist
# cursor.execute("""
# CREATE TABLE IF NOT EXISTS Inventory_11 (
#     id int primary key,
#     product_id INT,
#     quantity INT
# );
# """)

# connection.commit()

# # Function to add a new inventory item
# def add_inventory_item():
#     id = input("Enter ID: ")
#     product_id = input("Enter Product ID: ")
#     quantity = input("Enter Quantity: ")

#     query = "INSERT INTO Inventory_11 (id, product_id, quantity) VALUES (%s, %s, %s)"
#     cursor.execute(query, (id, product_id, quantity))
#     connection.commit()

#     print("Inventory item added successfully.")

# # Function to fetch all inventory items
# def fetch_all_inventory():
#     query = "SELECT * FROM Inventory_11"
#     cursor.execute(query)

#     items = cursor.fetchall()
    
#     if items:
#         print("Inventory Items:")
#         for item in items:
#             print(item)
#     else:
#         print("No inventory items found.")

# while True:
#         print("\n----- Inventory Management System -----")
#         print("1. Add New Inventory Item")
#         print("2. Fetch All Inventory Items")
#         print("3. Exit")

#         choice = input("Enter your choice (1-3): ")

#         if choice == '1':
#             add_inventory_item()
#         elif choice == '2':
#             fetch_all_inventory()
#         elif choice == '3':
#             print("Exiting program.")
#             break
#         else:
#             print("Invalid choice. Please try again.")
# # Close the connection when done
# cursor.close()
# connection.close()




# Q. No. 2 [10 Marks]
# Perform DataFrame Operations on Employee Data
# Operations:
# Create a DataFrame from a dictionary of employee data:
# [Name, Age, Salary]
# Filter the DataFrame to show only employees with salaries above 50,000.
# Sort the DataFrame by the 'salary' column in descending order.

import pandas as pd

# Create a dictionary of employee data
employee_data = {
    'Name': ['roh', 'mina', 'raj', 'harshad', 'maheta'],
    'Age': [28, 34, 40, 29, 35],
    'Salary': [60000, 48000, 75000, 53000, 62000]
}

# Create a DataFrame from the dictionary
df = pd.DataFrame(employee_data)

# Filter the DataFrame to show only employees with salaries above 50,000
high_salary_employees = df[df['Salary'] > 50000]

# Sort the DataFrame by the 'Salary' column in descending order
sorted_df = df.sort_values(by='Salary', ascending=False)

# Display results
print("Employees with salary above 50,000:")
print(high_salary_employees)

print("\nEmployees sorted by salary (descending):")
print(sorted_df)
