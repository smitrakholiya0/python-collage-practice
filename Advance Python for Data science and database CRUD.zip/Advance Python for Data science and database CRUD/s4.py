# SET – 4
# Q. No. 1 [15 Marks]
# Create a MySQL table books with:
# Book_ID, Title, Author, Genre, Availability_Status
# Add new books to the database.
# Retrieve available books based on genre.
# Update the availability of a book.
# Delete books that are no longer in stock.

# import mysql.connector

# # Connect to the database
# connection = mysql.connector.connect(
#     host='localhost',
#     database='exam_11',  
#     user='root',
#     password=''       
# )
# cursor = connection.cursor()

# cursor.execute("""
# CREATE TABLE IF NOT EXISTS books (
#     Book_ID INT PRIMARY KEY,
#     Title VARCHAR(255),
#     Author VARCHAR(255),
#     Genre VARCHAR(100),
#     Availability_Status VARCHAR(50)
# );
# """)

# # Function to add new books
# def add_book():
#     Book_ID = int(input("Enter Book ID: "))
#     title = input("Enter book title: ")
#     author = input("Enter author name: ")
#     genre = input("Enter genre: ")
#     availability_status = input("Enter availability status only (YES/NO): ")

#     query = "INSERT INTO books (Book_ID, Title, Author, Genre, Availability_Status) VALUES (%s, %s, %s, %s, %s)"
#     values = (Book_ID, title, author, genre, availability_status)
#     cursor.execute(query, values)
#     connection.commit()
#     print("Book added successfully.")

# # Function to retrieve available books by genre
# def get_available_books_by_genre():
#     genre = input("Enter genre to search for available books: ")

#     query = "SELECT * FROM books WHERE Genre = %s AND Availability_Status = 'YES'"
#     cursor.execute(query, (genre,))
#     results = cursor.fetchall()

#     if results:
#         for row in results:
#             print(row)
#     else:
#         print("No available books found in this genre.")

# # Function to update the availability of a book
# def update_availability():
#     book_id = int(input("Enter Book ID to update availability: "))
#     new_status = input("Enter new availability status (Available/Not Available): ")

#     query = "UPDATE books SET Availability_Status = %s WHERE Book_ID = %s"
#     cursor.execute(query, (new_status, book_id))
#     connection.commit()
#     print("Book availability updated successfully.")

# # Function to delete books that are no longer in stock
# def delete_books_not_in_stock():
#     query = "DELETE FROM books WHERE Availability_Status = 'NO'"
#     cursor.execute(query)
#     connection.commit()
#     print("Books that are no longer in stock have been deleted.")

# # Main menu loop
# while True:
#     print("\n----- Book Management System -----")
#     print("1. Add New Book")
#     print("2. View Available Books by Genre")
#     print("3. Update Book Availability")
#     print("4. Delete Books Not in Stock")
#     print("5. Exit")

#     choice = input("Enter your choice (1-5): ")

#     if choice == '1':
#         add_book()
#     elif choice == '2':
#         get_available_books_by_genre()
#     elif choice == '3':
#         update_availability()
#     elif choice == '4':
#         delete_books_not_in_stock()
#     elif choice == '5':
#         print("Exiting program.")
#         break
#     else:
#         print("Invalid choice. Please try again.")

# # Close the connection
# cursor.close()
# connection.close()





# Q. No. 2 [10 Marks]
# Write a Python program to perform the following:
# Read a CSV file named inventory_data.csv into a pandas DataFrame with fields:
# (item_id, name, category, quantity, price_per_item)
# Display number of rows and columns of the DataFrame.
# Find the category with the highest number of items in inventory.
# Display last 5 records.
# Filter the DataFrame to show only items with quantities below 10.


import pandas as pd

# Read CSV file into a pandas DataFrame
df = pd.read_csv('s4.csv')

# Display number of rows and columns
print("Number of rows and columns:", df.shape)

# Find the category with the highest number of items in inventory
category_counts = df['category'].value_counts() 
highest_category = category_counts.idxmax() 
print("\n Category with highest number of items:", highest_category)

# Display the last 5 records
print("\nLast 5 records:")
print(df.tail())

# Filter items with quantities below 10
low_stock_items = df[df['quantity'] < 10]
print("\nItems with quantities below 10:")
print(low_stock_items)
