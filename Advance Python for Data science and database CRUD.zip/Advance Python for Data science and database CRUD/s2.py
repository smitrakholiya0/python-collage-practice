# SET – 2
# Q. No. 1 [15 Marks]
# Create a DataFrame from a dictionary with:
# Name, Age, Department, Salary.
# Perform the following:
# Display first and last 2 records of the DataFrame.
# Display missing values
# Delete missing salary for department.
# Display highest salary per department.
# Create a histogram showcasing employee name with salary.

import pandas as pd
import matplotlib.pyplot as plt

# Step 1: Create the DataFrame
data = {
    'Name': ['Raj', 'Mitul', 'Ayush', 'Dev', 'Ashok', 'Purv'],
    'Age': [25, 30, 35, 40, 28, 45],
    'Department': ['HR', 'IT', 'Finance', 'HR', 'Finance', 'IT'],
    'Salary': [50000, None, 70000, 60000, 20000, 70000]
}
df = pd.DataFrame(data)

# Step 2–5: Data processing
print("First 2 records:")
print(df.head(2))
print("\nLast 2 records:")
print(df.tail(2))
print("\nMissing values:")
print(df.isnull().sum())

df_cleaned = df.dropna(subset=['Salary'])

print("\nHighest salary per department:")
print(df_cleaned.groupby('Department')['Salary'].max())

# ✅ Step 6: Bar chart of employee names with salary
plt.bar(df_cleaned['Name'], df_cleaned['Salary'])
plt.xlabel('Employee Name')
plt.ylabel('Salary')
plt.title('Employee Salary Distribution')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()











# Q. No. 2 [15 Marks]
# Create a MySQL table employees with:
# ID, Name, Position, Department, Salary.
# Develop a Python program to:
# Insert multiple employee records.
# Display all the employees sorted by salary.
# Update the department of an employee.
# Delete an employee record.



# import mysql.connector

# # Connect to MySQL
# conn = mysql.connector.connect(
#     host="localhost",
#     user="root",      
#     password="",  
#     # database="exam_11"  # You can set this if the database already exists.
# )
# cursor = conn.cursor()

# # Create the database if it doesn't exist and use it
# cursor.execute("CREATE DATABASE IF NOT EXISTS exam_11")
# cursor.execute("USE exam_11")

# # Create the 'employees' table if it doesn't exist
# cursor.execute("""
#     CREATE TABLE IF NOT EXISTS employees (
#         ID INT PRIMARY KEY,
#         Name VARCHAR(100),
#         Position VARCHAR(100),
#         Department VARCHAR(100),
#         Salary FLOAT
#     )
# """)
# def insert_data():
#     # Insert multiple records
#     # employees = [
#     #     (1, 'Raj', 'Manager', 'HR', 60000),
#     #     (2, 'Mitul', 'Developer', 'IT', 75000),
#     #     (3, 'Ayush', 'Analyst', 'Finance', 70000),
#     #     (4, 'Dev', 'Clerk', 'HR', 50000)
#     # ]

#     # cursor.executemany("INSERT INTO employees (ID, Name, Position, Department, Salary) VALUES (%s, %s, %s, %s, %s)", employees)
#     # conn.commit()
#     # print("Employees inserted successfully.")

#     # Display all employees sorted by salary
#     pass

# def display_data():
#     cursor.execute("SELECT * FROM employees ORDER BY Salary")
#     for row in cursor.fetchall():
#         print(row)

# def update_data():
#     # Update the department of an employee
#     emp_id = int(input("enter empid : "))
#     new_dept = input("enetr department type")
#     cursor.execute("UPDATE employees SET Department = %s WHERE ID = %s", (new_dept, emp_id))
#     conn.commit()
#     print(f"Updated department for employee ID {emp_id}.")

# def delete_data():
#     # Delete an employee record
#     delete_id = int(input("enetr id for delete"))
#     cursor.execute("DELETE FROM employees WHERE ID = %s", (delete_id,))
#     conn.commit()
#     print(f"Deleted employee with ID {delete_id}.")


# while True:
#     print("===== Student Menu =====")
#     print("1. Insert Student")
#     print("2. Display All Students")
#     print("3. Update Student Grade")
#     print("4. Delete Student")
#     print("5. Exit")
#     choice = input("Enter your choice (1-5): ")

#     if choice == '1':
#         insert_data()
#         pass
#     elif choice == '2':
#         display_data()
#         pass
#     elif choice == '3':
#         update_data()
#         pass
#     elif choice == '4':
#         delete_data()
#         pass
#     elif choice == '5':
#         break
#     else:
#         print("Invalid choice. Try again.\n")


# # Close connection
# cursor.close()
# conn.close()



